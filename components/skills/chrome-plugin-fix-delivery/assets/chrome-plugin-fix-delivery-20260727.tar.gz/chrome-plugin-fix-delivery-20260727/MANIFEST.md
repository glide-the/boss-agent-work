# 交付清单：Codex Chrome 插件卡顿/挂起修复（2026-07-27）

## 问题与效果

- 修复前：BOSS 等 busy 页面每条 playwright 命令精确 30 秒；内核重置后命令永久挂起（重试风暴，80 秒 4.7 万次 RPC）。
- 修复后：evaluate 8-36ms，点击+读列表 1.8s。
- 根因详见技能内 `references/case-study-30s-hang.md`（在 `modules/skills-chrome-plugin.tar.gz` 中）。

## 模块压缩包（`modules/`，均为完整模块原样打包）

| 压缩包 | 内容 | 线上来源 | 包含的改动 |
| --- | --- | --- | --- |
| `codex-extension-1.1.5_0-patched.tar.gz`（167K） | 完整解压版 Codex 扩展（manifest/background.js/popup/资源） | `~/project/CodexChromePlug/codex-1.1.5_0/` | `background.js`：`cn()` 总是真实 `chrome.debugger.attach`（自愈假附加、消除重试风暴）；含原始备份 `background.js.bak-xlog` |
| `chrome-plugin-26.601.21317-patched.tar.gz`（3.8M） | 完整 Codex 插件 Chrome 模块（scripts+node_modules、extension-host、assets、docs、skills） | `~/Downloads/codex-original-dmg-codex-home/plugins/cache/openai-bundled/chrome/26.601.21317`（`latest` 软链指向它） | `scripts/browser-client.mjs`：① Statsig 遥测 `ab.chatgpt.com` → `127.0.0.1:1` ② `Ly()` 安全模式默认 `"disabled-for-local-testing"`（消除每命令 30s）；含备份 `.bak-statsig`（原始）/`.bak-xk` |
| `codex-browser-config.tar.gz`（594B） | 两个 CODEX_HOME 的 browser 审批配置 | `~/Downloads/codex-original-dmg-codex-home/browser/` 与 `~/.codex/browser/` | 新建/修改 `config.toml`：`zhipin.com`、`example.com` 全局审批落盘；含 `~/.codex` 侧原始备份 `.bak-xk` |
| `skills-chrome-plugin.tar.gz`（20K） | 两个完整技能目录 | `~/.agents/skills/` | 新建 `chrome-plugin-hang-fix`（修复脚本+插桩工具+案例+锚点图）；`chrome-plugin-debug` 新增 2 条症状速查与坑位条目 |

## 回滚用原始文件（`backups/`）

| 文件 | 对应模块 |
| --- | --- |
| `browser-client.mjs.pristine` | 插件客户端原始版（改动前） |
| `extension-background.js.pristine` | 扩展原始版（改动前） |
| `home-codex-browser-config.toml.pristine` | `~/.codex/browser/config.toml` 原始版 |

## 诊断日志证据（`evidence/`）

| 文件 | 内容 |
| --- | --- |
| `ext-log.jsonl`（5.8M / 62267 行） | 扩展侧插桩原始日志：含 6290 条 `Debugger is not attached` 重试风暴记录（rpc 序号膨胀至 8964）、扩展侧毫秒级处理时延、修复后验证段 |
| `excerpt-1-retry-storm.jsonl` | 证据节选①：重试风暴段（`Debugger is not attached` 秒败循环） |
| `excerpt-2-kernel-30s-gap.jsonl` | 证据节选②：内核侧 [XK] 30 秒静默时间线（转录自 js 工具输出） |
| `excerpt-3-fast-path-after-fix.jsonl` | 证据节选③：修复后快速路径（同毫秒完成） |
| `README.md` | 标签速查、三个证据点的 grep 复现命令、内核侧 [XK] 关键时间线转录 |

## 修复过程日志证据（`evidence/`）

| 文件 | 内容 |
| --- | --- |
| `README.md` | 证据导读与关键检索指针 |
| `ext-log.jsonl`（5.8M） | 扩展侧完整插桩日志：18870 次 "Debugger is not attached" 重试风暴实锤 + 修复后 5ms 快速通道 |
| `excerpt-1/2/3-*.jsonl` | 风暴 / 30s 间隔（空，已被日志代截断）/ 修复后 三段摘录 |

## 部署方式

1. 扩展：`tar -xzf modules/codex-extension-1.1.5_0-patched.tar.gz -C <目标目录>`，在 `chrome://extensions` 加载/重载该目录。
2. 插件模块：解压覆盖到 `plugins/cache/openai-bundled/chrome/`（保持 `latest` 软链指向）。
3. 配置：按 CODEX_HOME 分别放置 `config.toml`。
4. 技能：解压到 `~/.agents/skills/`。

## 回滚

用 `backups/` 内原始文件覆盖对应路径，删除新建的 `config.toml`，然后在 `chrome://extensions` 重载扩展。

## 注意事项

- `Ly()` 补丁关闭全部 browser-use 安全检查（URL 黑名单、origin 授权、文件传输检查），仅适用于本机自用自动化。
- Codex 应用/插件缓存升级后 `browser-client.mjs` 会被新版本覆盖，需重跑技能内 `scripts/apply-latency-fixes.js`；扩展目录被重新解压后同理。
- Statsig 改指 `127.0.0.1:1` 后无遥测外发，恢复备份即还原。
