# 诊断日志证据说明

`ext-log.jsonl`（5.8M，62267 行）：2026-07-27 下午对插件链路双侧插桩时，扩展 Service Worker 侧通过 WebSocket 上报的原始日志（收集器：`chrome-plugin-hang-fix/scripts/log-collector.js`）。每行一个 JSON：`{"t": <epoch_ms>, "tag": <探点名>, "data": {...}}`。

## 标签速查

| tag | 含义 |
| --- | --- |
| `sw.start` | 扩展 Service Worker 启动（插桩代码已加载） |
| `rpc.in` / `rpc.out` | 扩展收到/回复 native-host JSON-RPC（id 形如 `native-host:<通道>:<序号>`） |
| `attach.begin/ok/err` | `chrome.debugger.attach` 调用与结果 |
| `execCdp.in/ok/err` | session 层 CDP 命令进入/成功/失败 |
| `En.begin/resp/cmdErr/timeout` | CDP 命令竞速（10s 超时）各阶段 |
| `dbg.onDetach` / `dbg.onEvent` | Chrome 调试器断开/事件（事件最多记 400 条） |
| `kernel` | 内核侧 [XK] 探针（本文件片段中未覆盖；内核侧关键时间线见下） |

## 证据点与复现命令

1. **重试风暴（根因三）**：`grep -c 'En.cmdErr' ext-log.jsonl` → 6290 次 `Debugger is not attached to the tab with id: 1521614758`；`grep -o 'native-host:[0-9]*:[0-9]*' ext-log.jsonl` 可见单会话 rpc 序号膨胀到 8964（正常会话 <100）。
2. **扩展侧处理只需毫秒级（排除扩展/CDP 嫌疑）**：`grep 'En.begin' ext-log.jsonl | head` 与同方法 `En.resp` 的 `t` 相差 1-13ms。
3. **修复后验证（尾部）**：文件末尾 `1785148787xxx` 段，`En.begin` 与 `En.resp` 同毫秒，rpc 序号正常（对照风暴段）。

## 内核侧 [XK] 关键时间线（来自 js 工具输出转录）

30 秒停顿定位（修复前，BOSS 页面 evaluate，总长 30062ms）：

```
sock.send m=getTabs        t=1785147709538
sock.recv id=15            t=1785147709548   <-- 之后内核静默 30.0s（无任何 sock 流量）
pweval.enter               t=1785147739562
cdp.Page.getFrameTree      t=1785147739563 → apiDone 739574
cdp.Page.createIsolatedWorld 739575 → 739587
cdp.Runtime.evaluate       739588 → 739599   <-- 实际执行仅 37ms
```

修复后同一操作：eval1 36ms / eval2 8ms（`pweval.enter` 紧随 getTabs，无静默期）。

安全检查链证据（Ic 探针）：

```
[XK] Ic.in  res={"kind":"origin","origin":"https://www.zhipin.com"} conv=019fa2d1-...
[XK] Ic.out {"decision":"approve","scope":"conversation","source":"browser-use-persisted-state"}
```

→ origin 审批本身走通了（elicitation 未触发），证明 30s 来自同链条的 `throwIfBlocksUrl`（site_status 网络请求超时），从而锁定 `Ly()` 补丁。
